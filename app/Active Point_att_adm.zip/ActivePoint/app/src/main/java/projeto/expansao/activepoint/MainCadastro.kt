 package projeto.expansao.activepoint
 
 import android.app.Activity
 import android.content.Context
 import android.content.Intent
 import android.os.Bundle
 import android.view.View
 import android.widget.Toast
 import projeto.expansao.activepoint.databinding.CadastroBinding
 
 class MainCadastro : Activity() {
 
     private lateinit var binding: CadastroBinding
 
     private fun showToast(message: String) {
         Toast.makeText(this, message, Toast.LENGTH_LONG).show()
     }
 
     private fun clearViews() {
         binding.edtTextNome.text.clear()
         binding.edtTxtEmail.text.clear()
         binding.edtPass.text.clear()
         binding.edtPhone.text.clear()
         binding.cnpj.text.clear()  // Limpar CNPJ se necessário
         binding.nomeloja.text.clear()  // Limpar Nome da Loja
     }
 
     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)
 
         binding = CadastroBinding.inflate(layoutInflater)
         setContentView(binding.root)
 
         // Listener para o RadioGroup
         binding.radioGroupOptions.setOnCheckedChangeListener { _, checkedId ->
             when (checkedId) {
                 R.id.radioOption1 -> {
                     // Se "Sou usuário" for selecionado, esconder os campos CNPJ e Nome da Loja
                     binding.cnpj.visibility = View.GONE
                     binding.nomeloja.visibility = View.GONE
                 }
                 R.id.radioOption2 -> {
                     // Se "Sou Loja" for selecionado, mostrar os campos CNPJ e Nome da Loja
                     binding.cnpj.visibility = View.VISIBLE
                     binding.nomeloja.visibility = View.VISIBLE
                 }
             }
         }
 
         // Listener para o botão "Fazer Cadastro"
         binding.cadastar.setOnClickListener {
             // Captura as informações inseridas pelo usuário
             val nomeCompleto = binding.edtTextNome.text.toString()
             val email = binding.edtTxtEmail.text.toString()
             val senha = binding.edtPass.text.toString()
             val numeroT = binding.edtPhone.text.toString()
             val cnpj = binding.cnpj.text.toString()
             val nomeLoja = if (binding.nomeloja.visibility == View.VISIBLE) {
                 binding.nomeloja.text.toString()
             } else {
                 ""  // Se o campo nomeLoja não estiver visível, passamos uma string vazia
             }
 
             // Verificação de campos obrigatórios
             if (nomeCompleto.isEmpty() || email.isEmpty() || senha.isEmpty() || numeroT.isEmpty()) {
                 showToast("Preencha todos os campos obrigatórios.")
                 return@setOnClickListener
             }
 
             // Verifica se o usuário é uma loja (checkbox marcado)
             val isLoja = binding.radioOption2.isChecked
 
             val controlador = BD_Controller(this)
 
             // Inserção de dados no banco de dados, dependendo se é um usuário comum ou uma loja
             val resultado = if (isLoja) {
                 // Inserir dados na tabela admin (para lojas)
                 controlador.inserirDadosAdmin(nomeCompleto, email, senha, numeroT, cnpj, nomeLoja)
             } else {
                 // Inserir dados na tabela de usuários comuns (login)
                 controlador.inserirDados(nomeCompleto, email, senha, numeroT)
             }
 
             // Exibe uma mensagem de resultado
             showToast(resultado)
 
             // Limpa os campos após o cadastro
             clearViews()
 
             // Redireciona para a tela de Login após o cadastro
             val intent = Intent(this, MainActivity::class.java)
             startActivity(intent)
             finish() // Fecha a tela de cadastro
         }
 
         // Listener para o botão "Fazer Login"
         binding.fazerLogin.setOnClickListener {
             // Captura as credenciais do usuário
             val email = binding.edtTxtEmail.text.toString()
             val senha = binding.edtPass.text.toString()
 
             val controlador = BD_Controller(this)
 
             // Verifica no banco de dados se as credenciais são de um usuário comum ou admin
             val resultadoLogin = controlador.verificarLogin(email, senha)
 
             // Verifica se o mapa retornado não é nulo e acessa o tipo de usuário
             if (resultadoLogin != null) {
                 val tipoUsuario = resultadoLogin["tipo"]
 
                 if (tipoUsuario == "admin") {
                     // Se for admin, redireciona para a tela de administração
                     val intent = Intent(this, AdminLayout::class.java)
                     startActivity(intent)
                     finish()  // Fecha a tela de cadastro
                 } else if (tipoUsuario == "usuario") {
                     // Caso o usuário seja comum, faça o login normal
                     showToast("Login realizado com sucesso!")
                     // Aqui você pode redirecionar o usuário para a tela normal
                 } else {
                     showToast("Credenciais inválidas.")
                 }
             } else {
                 showToast("Credenciais inválidas.")
             }
         }
     }
 }





