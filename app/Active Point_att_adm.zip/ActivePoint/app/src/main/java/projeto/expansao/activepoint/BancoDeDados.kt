package projeto.expansao.activepoint

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BancoDeDados(context: Context) : SQLiteOpenHelper(context, "ActivePointDB", null, 1) {

    companion object {
        const val TABELA = "usuarios"
        const val TABELA_ADMIN = "admin"
        const val NOME = "nome"
        const val EMAIL = "email"
        const val SENHA = "senha"
        const val TELEFONE = "telefone"
        const val CNPJ = "cnpj"
        const val NUMERO = "numero"
        const val NOME_DA_LOJA = "nome_da_loja"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableUsuarios = """
            CREATE TABLE $TABELA (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                $NOME TEXT,
                $EMAIL TEXT,
                $SENHA TEXT,
                $TELEFONE TEXT
            )
        """.trimIndent()

        val createTableAdmin = """
            CREATE TABLE $TABELA_ADMIN (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                $NOME TEXT,
                $EMAIL TEXT,
                $SENHA TEXT,
                $NUMERO TEXT,
                $CNPJ TEXT,
                $NOME_DA_LOJA TEXT
            )
        """.trimIndent()

        db?.execSQL(createTableUsuarios)
        db?.execSQL(createTableAdmin)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABELA")
        db?.execSQL("DROP TABLE IF EXISTS $TABELA_ADMIN")
        onCreate(db)
    }

    // Método para buscar usuários comuns (não administradores)
    fun getUsuariosComuns(): List<Map<String, String>> {
        val usuarios = mutableListOf<Map<String, String>>()
        val db = readableDatabase

        // Consulta SQL para pegar os dados dos usuários comuns (sem CNPJ)
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABELA WHERE $CNPJ IS NULL", null)

        if (cursor.moveToFirst()) {
            do {
                val usuario = mutableMapOf<String, String>()
                usuario["nome"] = cursor.getString(cursor.getColumnIndex(NOME))
                usuario["email"] = cursor.getString(cursor.getColumnIndex(EMAIL))
                usuario["telefone"] = cursor.getString(cursor.getColumnIndex(TELEFONE))
                // Adicione mais campos conforme necessário
                usuarios.add(usuario)
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return usuarios
    }
    fun verificarLogin(email: String, senha: String): Map<String, String>? {
        val queryUsuarios = "SELECT * FROM ${BancoDeDados.TABELA} WHERE ${BancoDeDados.EMAIL} = ? AND ${BancoDeDados.SENHA} = ?"
        val cursorUsuarios: Cursor = readableDatabase.rawQuery(queryUsuarios, arrayOf(email, senha))

        if (cursorUsuarios.moveToFirst()) {
            val usuario = mutableMapOf<String, String>()
            usuario["nome"] = cursorUsuarios.getString(cursorUsuarios.getColumnIndex(BancoDeDados.NOME))
            usuario["email"] = cursorUsuarios.getString(cursorUsuarios.getColumnIndex(BancoDeDados.EMAIL))
            usuario["telefone"] = cursorUsuarios.getString(cursorUsuarios.getColumnIndex(BancoDeDados.TELEFONE))
            usuario["tipo"] = "comum" // Marca como usuário comum

            cursorUsuarios.close()
            return usuario
        }

        // Verifica se é um administrador (loja)
        val queryAdmin = "SELECT * FROM ${BancoDeDados.TABELA_ADMIN} WHERE ${BancoDeDados.EMAIL} = ? AND ${BancoDeDados.SENHA} = ?"
        val cursorAdmin: Cursor = readableDatabase.rawQuery(queryAdmin, arrayOf(email, senha))

        if (cursorAdmin.moveToFirst()) {
            val admin = mutableMapOf<String, String>()
            admin["nome"] = cursorAdmin.getString(cursorAdmin.getColumnIndex(BancoDeDados.NOME))
            admin["email"] = cursorAdmin.getString(cursorAdmin.getColumnIndex(BancoDeDados.EMAIL))
            admin["numero"] = cursorAdmin.getString(cursorAdmin.getColumnIndex(BancoDeDados.NUMERO))
            admin["cnpj"] = cursorAdmin.getString(cursorAdmin.getColumnIndex(BancoDeDados.CNPJ))
            admin["nome_da_loja"] = cursorAdmin.getString(cursorAdmin.getColumnIndex(BancoDeDados.NOME_DA_LOJA))
            admin["tipo"] = "admin" // Marca como administrador

            cursorAdmin.close()
            return admin
        }

        cursorAdmin.close()
        return null // Retorna null se as credenciais não forem encontradas
    }
}
