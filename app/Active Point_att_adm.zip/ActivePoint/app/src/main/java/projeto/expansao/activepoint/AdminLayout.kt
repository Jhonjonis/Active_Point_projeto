package projeto.expansao.activepoint

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import projeto.expansao.activepoint.databinding.AdminLayoutBinding

class AdminLayout : AppCompatActivity() {

    private lateinit var binding: AdminLayoutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = AdminLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Instancia o banco de dados
        val bancoDeDados = BancoDeDados(this)

        // Obtém os usuários comuns do banco de dados
        val usuarios = bancoDeDados.getUsuariosComuns()

        // Configura o RecyclerView
        val recyclerView = binding.recyclerViewMain // Certifique-se de ter um RecyclerView no seu layout XML
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Cria e configura o Adapter para o RecyclerView
        val adapter = UsuarioAdapter(this, usuarios)
        recyclerView.adapter = adapter
    }
}
