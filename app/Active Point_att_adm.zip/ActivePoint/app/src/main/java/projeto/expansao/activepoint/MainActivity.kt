package projeto.expansao.activepoint

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import projeto.expansao.activepoint.databinding.ComunLayoutBinding
import projeto.expansao.activepoint.databinding.LoginBinding

class MainActivity : ComponentActivity() {

    private lateinit var binding: LoginBinding
    private lateinit var bancoDeDados: BancoDeDados

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = LoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bancoDeDados = BancoDeDados(this)

        binding.btnLogin.setOnClickListener {
            // Obtém os valores inseridos pelo usuário nos campos de login
            val email = binding.edtEmail.text.toString()
            val senha = binding.edtPass.text.toString()

            // Verifica se os campos não estão vazios
            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Chama o método de verificação de login
            val usuario = bancoDeDados.verificarLogin(email, senha)

            if (usuario == null) {
                // Caso o usuário não seja encontrado (email ou senha incorretos)
                Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show()
            } else {
                // Login bem-sucedido
                Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()

                // Verifica o tipo de usuário (comum ou admin)
                if (usuario["tipo"] == "admin") {
                    // Redireciona para a tela de admin
                    val intent = Intent(this, AdminLayout::class.java)
                    startActivity(intent)
                    finish() // Fecha a tela de login
                } else {
                    // Redireciona para a tela de usuário comum
                    val intent = Intent(this, ComunLayoutBinding::class.java) // Troque ComunLayoutBinding por ComunLayout se essa for a Activity correta.
                    startActivity(intent)
                    finish() // Fecha a tela de login
                }
            }
        }

        binding.btnCadastro.setOnClickListener {
            // Redireciona para a tela de cadastro
            val intent = Intent(this, MainCadastro::class.java)
            startActivity(intent)
            finish()  // Isso finaliza a Activity atual (Login) antes de chamar o cadastro
        }
    }
}

