package projeto.expansao.activepoint

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class UsuarioAdapter(private val context: Context, private val usuarios: List<Map<String, String>>) : RecyclerView.Adapter<UsuarioAdapter.UsuarioViewHolder>() {

    class UsuarioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nomeTextView: TextView = itemView.findViewById(R.id.cpf)
        val cpfTextView: TextView = itemView.findViewById(R.id.none)
        val numeroTextView: TextView = itemView.findViewById(R.id.numero)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.user_admin_item, parent, false)
        return UsuarioViewHolder(view)
    }

    override fun onBindViewHolder(holder: UsuarioViewHolder, position: Int) {
        val usuario = usuarios[position]
        holder.nomeTextView.text = "Nome: ${usuario["nome"]}"
        holder.cpfTextView.text = "CPF: ${usuario["id"]}"  // Aqui você pode usar o ID ou o CPF se tiver essa informação
        holder.numeroTextView.text = "Número: ${usuario["telefone"]}"
    }

    override fun getItemCount(): Int {
        return usuarios.size
    }
}